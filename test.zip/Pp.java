package com.paisia.test.test;

public class Pp {

	String t;
	String c;
	String id;
	int n;
	
	
	public Pp(String t, String c, String id, int n) {
		super();
		this.t = t;
		this.c = c;
		this.id = id;
		this.n = n;
	}
	
	
}
