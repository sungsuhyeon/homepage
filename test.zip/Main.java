package com.paisia.test.test;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Pp> p = new ArrayList <>();
		tete tt = new tete();
		
		p.add(new Pp("충퀴벌레이야기","충퀴벌레는 변신하면 쎄진데요!!.","충퀴",1));
		p.add(new Pp("억퀴벌레이야기","억퀴는 변신을할수가 없는 직업이라네요....","억퀴",2));
		p.add(new Pp("블레이드?","블레이드는 역시 지속딜과 잔재각인이 좋은거같아요.","블퀴",3));
		
		Scanner sc = new Scanner(System.in);
		loop:
		while(true) {
		System.out.println("명령을 내려주세요 [1 : 글쓰기 , 2 : 글 리스트 , 3 : 글 읽기 , e : 종료 , d : 글삭제 ]");
		String cmd = sc.next();
		
		switch(cmd) {
		
		
		
		case "1" :
			
			System.out.println("******** 글 쓰기 ********");
			System.out.println("제목을 입력해주세요");
			String t = sc.next();
			System.out.println("내용을 입력해주세요");
			String c = sc.next();
			System.out.println("id를 입력해주세요");
			String id = sc.next();
			System.out.println("no을 입력해주세요");
			int n = sc.nextInt();
			
			break;
		case "2" :
			
		System.out.println("******** 글 리스트 ********");
		for(int i=0;i<p.size();i++) {
			System.out.print("NO: "+p.get(i).n+" ");
			System.out.print(", ");
			System.out.print("제목: "+p.get(i).t+" ");
			System.out.print(", ");
			System.out.print("ID: "+p.get(i).id);
			System.out.println();
			
		}
		break;
		case "3" :
			
			System.out.println("******** 글 읽기 ********");
			System.out.println("몇번째 글을 읽으시겠습니까?");
			String next = sc.next();
			for (int i=0;i<p.size();i++) {
				if(tt.Nchk2(p.get(i).c, next) == true) {
					System.out.println(p.get(i).c);
				}
				
				 
				
					
//					System.out.print("제목:"+p.get(i).t);
//					System.out.print(", ");
//					System.out.print("내용:"+p.get(i).c);
//					System.out.print(", ");
//					System.out.print("id:"+p.get(i).id);
//					System.out.print(", ");
//					System.out.println("No:"+p.get(i).n);
//				
			}
		
		break;
		case "e" :
			
			System.out.println("******** 종 료 ********");
			break loop;
		case "d" :
			
			System.out.println("******** 삭제 ********");
			System.out.println("몇번째 글을 삭제하시겠습니까");
			int d = sc.nextInt();
			for (int i=0;i<p.size();i++) {
				if(p.get(i).n == d) {
				p.remove(i);
				}
			}
			break;
		
		
		}
		
	}
	}
}
