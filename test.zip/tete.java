package com.paisia.test.test;

import java.util.regex.Pattern;

public class tete {
	   boolean Nchk2(String i , String s) {
		      boolean n_check = Pattern.matches(s, i);
		      if (n_check == false) {
//		         System.out.println("다른 수를 입력하셨습니다. 초기화면으로 돌아갑니다.");
		         return true;
		      } else {
		         return false;
		      }
		   }
}
